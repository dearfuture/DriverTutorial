Kernel Mode Driver Development Kit for MASM32 programmers.
v1.8 Januar 2005.


------------
DISCLAIMER
------------

This package is provided �as is�. You use it at YOUR OWN RISK, 
without warranty of ANY KIND, either expressed or implied. 
I accept no responsibility for any damage caused either 
directly or indirectly to your data, computer or business 
due to the use or misuse of this product.


------------
INSTALLATION
------------

Copy \include\            to  \masm32\include
Copy \macros\Strings.mac  to  \masm32\macros
Copy \lib\w2k             to  \masm32\lib

or simply run install.bat


------------
TUTTORIALS
------------

For tuts go to...

English. Currently only tuts #1-7 available.
http://www.freewebs.com/four-f/index.htm
http://www.masmforum.com/website/tutorials/kmdtute/index.html

Russian. Currently available tuts #1-16.
http://www.wasm.ru

----------------------
Four-F, four-f@mail.ru
