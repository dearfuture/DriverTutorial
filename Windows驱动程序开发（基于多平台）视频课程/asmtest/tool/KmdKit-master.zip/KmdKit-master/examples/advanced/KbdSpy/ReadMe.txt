
This is an example of a simple legacy (non PnP) PS/2-keyboard filter driver.
WARNING: You will fail to attach it to USB-keyboard stack.

Tested under: Windows 2000, XP and Server 2003.

______________________
Four-F, four-f@mail.ru