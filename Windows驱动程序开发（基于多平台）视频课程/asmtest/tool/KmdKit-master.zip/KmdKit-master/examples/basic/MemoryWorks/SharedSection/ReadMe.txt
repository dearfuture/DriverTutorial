
This is an example how to use named section object to share memory
between user mode process and kernel mode driver.

Tested under: Windows 2000, XP and Server 2003.

______________________
Four-F, four-f@mail.ru