
This is an example of one possible way to share
the memory buffer between user and kernel mode.

Tested under: Windows 2000, XP and Server 2003.

______________________
Four-F, four-f@mail.ru
