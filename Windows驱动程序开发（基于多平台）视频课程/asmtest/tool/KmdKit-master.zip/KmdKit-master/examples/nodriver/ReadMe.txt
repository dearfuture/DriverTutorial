
In these examples we do not create any device driver but deal with existing ones.

______________________
Four-F, four-f@mail.ru