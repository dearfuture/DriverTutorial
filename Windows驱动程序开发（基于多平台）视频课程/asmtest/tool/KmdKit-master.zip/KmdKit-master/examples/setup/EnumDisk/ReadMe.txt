
This is an example how to use some of the setup device functions.
Enumerates all available disk devices and gets the device property.
Run it from command line.

Tested on: Windows 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru