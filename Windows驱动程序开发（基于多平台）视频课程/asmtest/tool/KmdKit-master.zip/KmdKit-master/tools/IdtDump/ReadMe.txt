
Interrupt Descriptor Table Dumper

SoftICE cheats telling you that IDT is untouched.
Do not believe and use this tool to browse IDT content.

______________________
Four-F, four-f@mail.ru