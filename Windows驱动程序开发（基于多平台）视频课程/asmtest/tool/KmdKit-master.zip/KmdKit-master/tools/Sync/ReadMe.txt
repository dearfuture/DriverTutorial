
Sync - Let you flush your drives
before starting probably buggy device driver.

______________________
Four-F, four-f@mail.ru